# 智能题库系统 - 服务器部署包

## 🚀 快速部署

1. **上传并解压**：
   ```bash
   tar -xzf quiz-system-*.tar.gz
   cd quiz-system-deploy
   ```

2. **配置 API Key**：
   ```bash
   cp .env.example .env
   nano .env  # 编辑 AI_API_KEY
   ```

3. **一键部署**：
   ```bash
   chmod +x server-deploy.sh
   ./server-deploy.sh
   ```

## 📋 包含文件

- `server-deploy.sh` - 服务器端自动部署脚本
- `deploy.sh` - 项目部署管理脚本
- `docker-compose.yml` - Docker 服务编排
- `backend/` - 后端源码
- `study-app/` - 前端源码
- `nginx/` - Nginx 配置
- `.env.example` - 环境变量模板

## 🔑 获取 Gemini API Key

访问：https://aistudio.google.com/app/apikey

## 📞 支持

如遇问题，查看日志：`./deploy.sh logs`
